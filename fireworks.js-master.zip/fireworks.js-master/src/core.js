/**
 * Global namespace for the whole library
 * @namespace Global namespace for the whole library
 * @type {Object}
 */
var Fireworks	= {};

/**
 * enable or disable debug in the library
 * @type {Boolean}
 */
Fireworks.debug	= true;