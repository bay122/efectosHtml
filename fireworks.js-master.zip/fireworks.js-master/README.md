fireworks.js
============

Particles engine in javascript


ChangeLog:
* massive boost by removing console.assert() from fast path (from @tapio)