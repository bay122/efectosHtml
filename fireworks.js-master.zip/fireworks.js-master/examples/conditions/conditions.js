Fireworks.Condition	= function(){
	
}

/**
 * return {boolean} true if the condition is satisfied, 
*/
Firefly.Shape.prototype.satisfied	= function(particle){
	console.assert(false, 'not implemented');
	return false;
}
