/**
 * render to three.js to THREE.ParticleSystem
*/
Fireworks.EffectsStackBuilder.prototype.renderToThreejsParticleSystem	= function(opts)
{
	opts			= opts			|| {};
	var effectId		= opts.effectId		|| 'renderToThreejsParticleSystem';
	var particleSystem	= opts.particleSystem	|| defaultParticleSystem;
	// if opts.particleSystem is a function, call it to create the particleSystem
	if( typeof(particleSystem) === 'function' )	particleSystem	= particleSystem(this._emitter);
	// sanity check
	console.assert(particleSystem instanceof THREE.ParticleSystem, "particleSystem MUST be THREE.ParticleSystem");
	// some aliases
	var geometry	= particleSystem.geometry;
	console.assert(geometry.vertices.length >= this._emitter.nParticles())
	// create the effect itself
	Fireworks.createEffect(effectId, {
		particleSystem	: particleSystem
	}).onCreate(function(particle, particleIdx){
		particle.threejsParticle = {
			particleIdx	: particleIdx
		};
		var vertex	= geometry.vertices[particleIdx];
		vertex.set(Infinity, Infinity, Infinity);
	}).onDeath(function(particle){
		var particleIdx	= particle.threejsParticle.particleIdx;
		var vertex	= geometry.vertices[particleIdx];
		vertex.set(Infinity, Infinity, Infinity);
	}).onRender(function(particle){
		var particleIdx	= particle.threejsParticle.particleIdx;
		var vertex	= geometry.vertices[particleIdx];
		var position	= particle.position.vector;
		vertex.set(position.x, position.y, position.z);
	}).pushTo(this._emitter);
	return this;	// for chained API

	//////////////////////////////////////////////////////////////////////////
	//		Internal Functions					//
	//////////////////////////////////////////////////////////////////////////

	function defaultParticleSystem(emitter){
		var geometry	= new THREE.Geometry();
		for( var i = 0; i < emitter.nParticles(); i++ ){
			geometry.vertices.push( new THREE.Vector3() );
		}
		var material	= new THREE.ParticleBasicMaterial({
			size		: 5,
			sizeAttenuation	: true,
			color		: 0xE01B6A,
			map		: generateTexture(),
			blending	: THREE.AdditiveBlending,
			depthWrite	: false,
			transparent	: true
		});
		var particleSystem		= new THREE.ParticleSystem(geometry, material);
		particleSystem.dynamic		= true;
		particleSystem.sortParticles	= true;
		return particleSystem;
	}

	function generateTexture(size){
		size		= size || 128;
		var canvas	= document.createElement( 'canvas' );
		var context	= canvas.getContext( '2d' );
		canvas.width	= canvas.height	= size;

		var gradient	= context.createRadialGradient( canvas.width/2, canvas.height /2, 0, canvas.width /2, canvas.height /2, canvas.width /2 );		
		gradient.addColorStop( 0  , 'rgba(255,255,255,1)' );
		gradient.addColorStop( 0.5, 'rgba(255,255,255,1)' );
		gradient.addColorStop( 0.7, 'rgba(128,128,128,1)' );
		gradient.addColorStop( 1  , 'rgba(0,0,0,1)' );

		context.beginPath();
		context.arc(size/2, size/2, size/2, 0, Math.PI*2, false);
		context.closePath();

		context.fillStyle	= gradient;
		//context.fillStyle	= 'rgba(128,128,128,1)';
		context.fill();

		var texture	= new THREE.Texture( canvas );
		texture.needsUpdate = true;

		return texture;
	}
};

